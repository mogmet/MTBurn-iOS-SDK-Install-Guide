//
//  ADVSAppDelegate.h
//  DemoApp
//
//  Created by M.T.Burn on 2/11/14.
//  Copyright (c) 2014 M.T.Burn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADVSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (NSDictionary*)adspotIdDict;

@end
