//
//  ADVSInstreamAppTableViewController.h
//  DemoApp
//
//  Created by M.T.Burn on 2014/05/21.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADVSInstreamAppTableViewController : UITableViewController
- (void)setupAdCell:(Class)adCellClass index:(NSUInteger) index;
@end
