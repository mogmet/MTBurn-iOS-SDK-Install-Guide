//
//  ADVSInstreamAppPageController.h
//  DemoApp
//
//  Created by M.T.Burn on 2014/05/21.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//

#import "ViewPagerController.h"

@interface ADVSInstreamAppPageController : ViewPagerController<ViewPagerDataSource,ViewPagerDelegate>

@end
