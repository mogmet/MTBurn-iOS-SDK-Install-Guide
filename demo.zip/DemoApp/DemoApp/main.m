//
//  main.m
//  DemoApp
//
//  Created by M.T.Burn on 2/11/14.
//  Copyright (c) 2014 M.T.Burn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ADVSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ADVSAppDelegate class]));
    }
}
