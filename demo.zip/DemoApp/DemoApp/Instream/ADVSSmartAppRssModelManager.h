//
//  ADVSSmartAppRssModelManager.h
//  DemoApp
//
//  Created by M.T.Burn on 2014/04/21.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADVSSmartAppRssModelManager : NSObject
+(NSDictionary *) rssDictModel:(NSNumber *)index;
@end
