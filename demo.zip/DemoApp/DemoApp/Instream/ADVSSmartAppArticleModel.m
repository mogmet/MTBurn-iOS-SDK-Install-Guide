//
//  ArticleModel.m
//  DemoApp
//
//  Created by M.T.Burn on 2014/04/18.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//

#import "ADVSSmartAppArticleModel.h"

@implementation ADVSSmartAppArticleModel

@end
