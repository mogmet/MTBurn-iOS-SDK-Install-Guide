//
//  ADVSSmartAppColorPalette.h
//  DemoApp
//
//  Created by M.T.Burn on 2014/04/18.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface ADVSSmartAppColorPalette : NSObject

+ (UIColor *)colorWithIndex:(NSInteger)index;

@end
