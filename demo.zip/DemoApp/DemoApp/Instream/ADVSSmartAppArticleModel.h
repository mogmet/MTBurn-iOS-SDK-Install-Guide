//
//  ArticleModel.h
//  DemoApp
//
//  Created by M.T.Burn on 2014/04/18.
//  Copyright (c) 2014年 MTBurn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADVSSmartAppArticleModel : NSObject
@property (nonatomic) NSString *title;
@property (nonatomic) NSString *content;
@property (nonatomic) NSString *link;
@end
