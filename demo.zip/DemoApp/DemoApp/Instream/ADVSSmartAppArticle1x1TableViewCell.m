//
//  Article1x1TableViewCell.m
//  SmartNewsSample
//
//  Created by M.T.Burn on 2014/04/15.
//  Copyright (c) 2014年 M.T.Burn. All rights reserved.
//

#import "ADVSSmartAppArticle1x1TableViewCell.h"

@implementation ADVSSmartAppArticle1x1TableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
